#include "button.hpp"

using namespace genv;
using namespace std;

Button::Button(Window * w,int x, int y, int sx, int sy, string text, std::function<void()> f) : Widget(w,x,y,sx,sy), _text(text), _f(f)
{
}

void Button::rajzol() {
    if (_pressed)gout << move_to(a,b) << color(150,150,150) << box(size_a, size_b);
    else gout << move_to(a,b) << color(100,100,100) << box(size_a, size_b);
    if (_pressed) gout << move_to(a+_borderSize,b+_borderSize) << color(230,230,230) << box(size_a-(2*_borderSize),size_b-(2*_borderSize));
    else gout << move_to(a+_borderSize,b+_borderSize) << color(200,200,200) << box(size_a-(2*_borderSize),size_b-(2*_borderSize));
    gout.load_font("LiberationSans-Regular.ttf", 20);
    gout << move_to(((a+size_a/2)-gout.twidth(_text)/2), b+size_b/2-gout.cascent()+gout.cdescent()+_borderSize) << color(10,10,10) << text(_text);

}


void Button::handle(event ev)
{
    if (ev.button == btn_left) {
        _pressed = true;
    }
    else if (_pressed && ev.button == -btn_left) {
        _f();
        _pressed = false;
    }
    _focused = true;
}

#include "board.hpp"
#include "tile.hpp"

using namespace genv;
using namespace std;

Board::Board(Window * w,int x, int y, int sx, int sy, int sor, int oszlop,
             std::vector<string> player_1, std::vector<string> player_2,std::function<string(int x, int y, int sx, int sy, int borderSize)> f)
    : Widget(w,x,y,sx,sy), _sor(sor), _oszlop(oszlop), _f(f), _player_1(player_1), _player_2(player_2), _playerName(_player_1[0])
{

    int gap = 1;
    int tileSize = (size_a/_sor);
    while (gap < 2 && (((tileSize-gap)*sor + gap*((_sor+1))) <= size_a)) {
        if ((((tileSize-gap)*_sor + gap*(_sor+1)) > size_a)) tileSize--;
        else gap++;
    }
    _borderSize = gap+2;
    for (int r = 0; r < _sor; ++r) {
        int currentRow = a+(tileSize*r);
        for (int c = 0; c < _oszlop; ++c) {

            int plusSizeX = gap+2;
            int plusSizeY = gap+2;


            int currentCol = b+(tileSize*c);
            new Tile(_w,currentRow+gap+3, currentCol+gap+3,tileSize-plusSizeX+0, tileSize-plusSizeY+0,size_b/_oszlop,"",_f);
        }

    }
}

void Board::rajzol(){
    gout << move_to(0,0) << color(0,0,0) << box(_w->getWindowX(),_w->getWindowY());
    gout << move_to(a,b) << color(55,130,190) << box(size_a, size_b);
}

void Board::handle(genv::event ev){}

void Board::setPlayerName(string name) {
    _playerName = name;
}


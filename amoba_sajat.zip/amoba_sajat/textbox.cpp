#include "textbox.hpp"
#include "graphics.hpp"

using namespace genv;
using namespace std;


Textbox::Textbox(Window * w,int x, int y, int sx, int sy, int fontSize, string text)
    : Widget(w,x, y, sx, sy), _fontSize(fontSize),_text(text) {}


Textbox::Textbox(Window * w,int x, int y, int sx, int sy, int fontSize, string text, bool withBackground)
    : Widget(w,x, y, sx, sy), _fontSize(fontSize),_text(text), _withBackground(withBackground) {}


void Textbox::rajzol() {
    if (_withBackground) gout << move_to(a, b) << color(0,0,0) << box(size_a, size_b);
    gout << move_to(a, b);
    gout.load_font("LiberationSans-Regular.ttf", _fontSize);
    gout << color(255,255,255);
    gout << text(_text);
    gout << color(0,0,0);
}

void Textbox::setContent(string text) {
    _text = text;
}

void Textbox::handle(event ev)
{

}

string Textbox::getContent() {
    return _text;
}

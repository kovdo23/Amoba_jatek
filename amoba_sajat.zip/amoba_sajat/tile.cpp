#include "tile.hpp"

using namespace std;
using namespace genv;

Tile::Tile(Window * w,int x, int y, int sx, int sy, int fontSize, string text, std::function<string(int x, int y, int sx, int sy, int borderSize)> f)
    : Textbox(w,x, y, sx, sy, fontSize, text), _f(f)
{

}

void Tile::rajzol(){
    gout << move_to(a,b) << color(0,0,0) << box(size_a,size_b);
    gout << move_to(a+((size_a-gout.twidth(_text))/2),b-gout.cdescent()/2);
    gout.load_font("LiberationSans-Regular.ttf", _fontSize);
    gout << color(255,255,255);
    gout << text(_text);
}

void Tile::handle(genv::event ev){
    if (ev.button == btn_left) {
        _text = _f(a,b, size_a,size_b,_borderSize);
    }
}
